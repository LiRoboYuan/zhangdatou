#include "getJson.h"
#include "uart.h"
#include "circular_buffer.h"
#include <stdlib.h>
#include "main.h"
#include "cJSON.h"
#include "string.h"

uint8_t uart_rx_buffer[1024];
int read_sizE = 0;
uint8_t json_buffer_test[] = "{\"seq\":2,\"vendor\":[{\"sid\":\"123456\",\"data\":{\"key\":\"88888888\",\"ssid\":\"HS\"}}]}";
uint8_t json_buffer_test1[] ="{\"motor_mode\":\"1\",\"relay_flag\":\"2\",\"location_num\":\"4\",\"run_location\":\"5\",\"run_location1\":\"5\","
"\"test_location\":{\"location1\":\"1111\",\"location2\":\"1\",\"location3\":\"11111\",\"location4\":\"11111441141\"}}";


json_data_t jsondata;

int get_Json_data(void)
{
	int result = -1;  // 1 ��ʾ�ɹ�������ֵ��ʾ����
	uint16_t get_size = 0;

	//uint16_t uart_get_num = CircBuf_GetUsedSize(&USART0_RxCBuf);
//	memset(uart_rx_buffer, 0x00, sizeof(uart_rx_buffer));
//	if(uart_get_num > 0)
	{
		//get_size = CircBuf_Pop(&USART0_RxCBuf, uart_rx_buffer, uart_get_num);
	
		cJSON *cjson = NULL , *motor_mode = NULL;
		cjson = cJSON_Parse((const char*)uart_rx_buffer);
		memset(uart_rx_buffer,0x00,1024);
		if (cjson != NULL) {
//			// ��ȡ "motor_mode" �ֶ�
//			cJSON *motor_mode = cJSON_GetObjectItem(cjson, "motor_mode");
//			jsondata.motor_mode = atoi(motor_mode->valuestring);
//			switch(jsondata.motor_mode)
//			{
//				case 0:result=jsondata.motor_mode;break;//ʧ�ܵ��
//				case 1:result=jsondata.motor_mode;break;//ʹ�ܵ��
//				case 2:result=jsondata.motor_mode;break;//����ѹͷ�����Σ�
//				case 3:
//					result=jsondata.motor_mode;
//					cJSON *run_location  = cJSON_GetObjectItem(cjson, "run_location");
//					jsondata.run_location = atoi(run_location->valuestring);
//					printf("\n jsondata.run_location = %d",jsondata.run_location);
//					break;//�ƶ�ƽ̨
//				case 4:
//					result=jsondata.motor_mode;
//					cJSON *test_lactiong = cJSON_GetObjectItem(cjson, "test_lactiong");
//					jsondata.test_lactiong = atoi(test_lactiong->valuestring);
//					printf("\n jsondata.test_lactiong = %d",jsondata.test_lactiong);
//					break;//��סһ����λ
//				case 5:result=jsondata.motor_mode;break;//ɾȥһ����λ
//				case 6:
//					result=jsondata.motor_mode;
//					cJSON *run_test_num = cJSON_GetObjectItem(cjson, "run_test_num");
//					jsondata.run_test_num = atoi(run_test_num->valuestring);
//					printf("\n jsondata.run_test_num = %d",jsondata.run_test_num);
//					break;//������������
//			}

//			printf("\n result = %d",result);
			// �����ڴ�
			cJSON_Delete(cjson);
		}
		else {
				printf("\nError: JSON parsing failed  %d\n",get_size);
		}
	}

	return result;
}
int get_run_test_num(void){
	return	jsondata.run_test_num;
}
int get_run_test_laction(void){
	return	jsondata.test_lactiong;
}
int get_run_location(void){

	return jsondata.run_location;
}
